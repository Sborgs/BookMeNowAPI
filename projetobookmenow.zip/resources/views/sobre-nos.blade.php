@extends('layouts.site')

@section('conteudo')
    <section>
        <div class="secao-titulo">
            <div class="titulo">
                <h2>Sobre nós</h2>
            </div>
        </div>
        <div>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Inventore rem saepe placeat quae? Et, veniam nihil
                quo
                dicta molestias, corporis quas harum nulla neque recusandae officiis deleniti, corrupti omnis eaque.</p>
        </div>
    </section>
@endsection
