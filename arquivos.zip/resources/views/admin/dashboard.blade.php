@extends('layouts.admin')

@section('conteudo')
    <div class="d-flex justify-content-between mt-3">
        <h2>Dashboard</h2>
        <p>Área Administrativa</p>
    </div>
@endsection
